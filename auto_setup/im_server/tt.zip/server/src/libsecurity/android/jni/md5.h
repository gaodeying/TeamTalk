
#ifndef _MD5FILE_H_
#define _MD5FILE_H_
void MD5_Calculate (const char* pContent, unsigned int nLen,char* md5);
#endif
